from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib import messages

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            return redirect('index')  # Redirect to the index view on successful login
        else:
            messages.error(request, 'Invalid username or password.')
    
    return render(request, 'login.html')  # Render the login template if not POST

def index(request):
    return render(request, 'index.html')  # Render the index page
    
def sign_up(request):
    return render(request, 'signUp.html')    
def invest_in_business(request):
    return render(request, 'invest.html')

def find_investment(request):
    return render(request, 'find_investment.html')

def business_growth(request):
    return render(request, 'business_growth.html')

def profile(request):
    return render(request, 'profile.html')

def register_for_investment(request):
    return render(request, 'register.html')