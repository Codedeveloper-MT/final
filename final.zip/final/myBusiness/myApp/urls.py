from django.urls import path
from . import views  # Import your views

urlpatterns = [
    path('login/', views.login_view, name='login_view'),  # Define the login URL
    # Add other URL patterns here as needed
     path('signup/', views.sign_up, name='sign_up'),
     path('invest/', views.invest_in_business, name='invest_in_business'),
    path('find/', views.find_investment, name='find_investment'),
    path('growth/', views.business_growth, name='business_growth'),
    path('profile/', views.profile, name='profile'),
    path('register/', views.register_for_investment, name='register_for_investment'),
]